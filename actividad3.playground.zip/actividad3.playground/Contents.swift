import UIKit
/*:Actividad de Tipos de datos

A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
 */

var entero1:Int = 5
var flotante:Float = 5.104
var string1:String; string1 = "Hola Mundo"


/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
var string2:String = "hello"

//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.
var entero2:Int = 45

/*:
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numeros:Array<Int> = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

//y luego crea la variable diasSemana de tipo Dictionary con la relación numero:día Ej. 1:"Lunes”//

var diaSemana:Dictionary = [1: "Lunes",
                             2: "Martes",
                             3: "Miercoles",
                             4: "Jueves",
                             5: "Viernes",
                             6: "Sabado",
                             7: "Domingo"
                            ]
        

/* PAUL FRANCISCO GRANADOS OJEDA*/


